package org.cts;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.dao.SupplierBO;
import org.cts.model.Supplier;

/**
 * Servlet implementation class DeleteSupplier
 */
@WebServlet("/delete")
public class DeleteSupplier extends HttpServlet {
	private static final long serialVersionUID = 1L;
	SupplierBO supplierBo=new SupplierBO();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int id=Integer.parseInt(request.getParameter("id"));
		Supplier supplier=supplierBo.getSupplier(id);
		String msg=supplierBo.deleteSupplier(supplier);
		String msg1="Not Sucessfully Deleted";
		//PrintWriter pw=response.getWriter();
		if(msg.equals("Successfully Deleted"))
		{
		pw.println("<script type=\"text/javascript\">");
		pw.println("alert('Successfully Deleted');");
		pw.println("</script>");
		RequestDispatcher rd=request.getRequestDispatcher("supplier.jsp");
		rd.include(request, response);
		}
		else
		{
			pw.println("<script type=\"text/javascript\">");
			pw.println("alert('fails');");
			pw.println("</script>");
			RequestDispatcher rd=request.getRequestDispatcher("supplier.jsp");
			rd.include(request, response);
		}
	}

}
