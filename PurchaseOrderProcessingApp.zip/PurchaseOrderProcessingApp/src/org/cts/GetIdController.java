package org.cts;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.dao.SupplierBO;
import org.cts.dao.SupplierDao;

/**
 * Servlet implementation class GetIdController
 */
@WebServlet("/getId")
public class GetIdController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   	SupplierBO dao=new SupplierBO();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String name=request.getParameter("sname");
		//System.out.println(name);
		int id=dao.getId(name);
		request.setAttribute("id", id);
		RequestDispatcher rd=request.getRequestDispatcher("customer.jsp");
		rd.forward(request, response);
		pw.close();
		
	}

}
