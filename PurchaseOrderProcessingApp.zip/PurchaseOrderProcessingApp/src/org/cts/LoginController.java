package org.cts;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cts.dao.UserDao;
import org.cts.dao.UserDaoImpl;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/login")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserDao dao=new UserDaoImpl();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter pw=resp.getWriter();
		String uname=req.getParameter("uname");
		String pwd=req.getParameter("pwd");
		System.out.println(uname+"\t"+pwd);
		String utype=dao.validateUser(uname, pwd);
		System.out.println(utype);
		if(utype.equals("supplier"))
		{
			HttpSession session=req.getSession();
			session.setAttribute("uname", uname);
			RequestDispatcher rd=req.getRequestDispatcher("supplier.jsp");
			rd.forward(req, resp);
		}
		else if(utype.equals("customer")){
			HttpSession session=req.getSession();
			session.setAttribute("uname", uname);
			RequestDispatcher rd=req.getRequestDispatcher("customer.jsp");
			rd.forward(req, resp);
		}
		else
		{
			pw.println("<script type=\"text/javascript\">");
			pw.println("alert('Invalid UserName/password');");
			pw.println("</script>");
			RequestDispatcher rd=req.getRequestDispatcher("index.jsp");
			rd.include(req, resp);
		}
		
	}

}
