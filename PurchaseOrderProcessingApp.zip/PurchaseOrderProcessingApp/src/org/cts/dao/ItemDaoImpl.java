package org.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.cts.model.Item;
import org.cts.model.Supplier;
import org.cts.util.DBConstants;
import org.cts.util.DBUtil;

public class ItemDaoImpl implements ItemDao{
	Connection con=null;
	PreparedStatement ps=null;
	@Override
	public String addItem(Item t) {
		String msg="";
		int r=0;
		try{
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME,DBConstants.PWD);
			 ps=con.prepareStatement("insert into item(description,available_quantity,reorder_level,status,puchase_cost,purchase_quantity,supplier_id) value(?,?,?,?,?,?,?)");
			 ps.setString(1,t.getDescription());
			 ps.setInt(2,t.getAvailableQuantity());
			 ps.setInt(3,t.getReorderLevel());
			// ps.setString(4,t.getStatus());
			 ps.setInt(5,t.getPurchaseCost());
			// ps.setString(6,t.getPuchaseQuantity());
			 ps.setInt(7,t.getSupplierId());
			 r=ps.executeUpdate();
			 if(r>0)
				 msg=msg+"Successfully Inserted";
			 con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return msg;
	}

	@Override
	public String delete(Item t) {
		String msg="";
		int r=0;
		try{
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME,DBConstants.PWD);
			 ps=con.prepareStatement("delete from item where id=?");
			 ps.setInt(1, t.getId());
			 r=ps.executeUpdate();
			 if(r>0)
				 msg=msg+"Successfully Deleted";
			 con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return msg;
	}

	@Override
	public List<Item> getItem(int supplierId) {
		List<Item> itemList=new ArrayList<Item>();
		try{
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME,DBConstants.PWD);
			PreparedStatement ps=con.prepareStatement("Select * from item where supplier_id=?");
			ps.setInt(1, supplierId);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
			itemList.add(new Item(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4), rs.getInt(5),rs.getInt(6),rs.getString(7)));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return itemList;
	}

	@Override
	public Item getItem1(int itemId) {
		Item item=new Item();
		try{
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME,DBConstants.PWD);
			PreparedStatement ps=con.prepareStatement("Select * from item where id=?");
			ps.setInt(1, itemId);
			ResultSet rs=ps.executeQuery();
			rs.next();
			item=new Item(rs.getString(2),rs.getInt(3) , rs.getInt(4), rs.getInt(5), rs.getInt(6), rs.getString(7));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return item;
	}

}
