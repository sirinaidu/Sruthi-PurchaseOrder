package org.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.cts.util.DBConstants;
import org.cts.util.DBUtil;

public class UserDaoImpl implements UserDao {

	@Override
	public String validateUser(String uname, String pwd) {
		Connection con=null;
		PreparedStatement pst=null;
		String utype="";
		try {
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
			pst=con.prepareStatement("select utype from user where name=? and pwd=?");
			pst.setString(1, uname);
			pst.setString(2, pwd);
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				utype=utype+rs.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return utype;
	}

}
