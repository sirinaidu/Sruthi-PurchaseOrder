package org.cts.dao;

public interface UserDao {
	String validateUser(String uname,String pwd);
}
