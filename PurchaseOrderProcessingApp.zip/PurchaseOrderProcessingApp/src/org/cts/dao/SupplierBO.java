package org.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.cts.model.Supplier;
import org.cts.util.DBConstants;
import org.cts.util.DBUtil;

public class SupplierBO implements SupplierDao{
	Connection con=null;
	@Override
	public Supplier getSupplier(int id) {
		// TODO Auto-generated method stub
		Supplier s=null;
		try{
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME,DBConstants.PWD);
			PreparedStatement ps=con.prepareStatement("Select * from supplier where id=?");
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			rs.next();
			id=rs.getInt(1);
			s=new Supplier(id,rs.getString(2),rs.getString(3),rs.getString(4), rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return s;
	}
	@Override
	public String addSupplier(Supplier s) {
		PreparedStatement ps=null;
		int r=0;
		String msg="";
		try{
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME,DBConstants.PWD);
			 ps=con.prepareStatement("insert into supplier(supplier_name,city,address,e_mail_id,fax,phone_no,contact_person) value(?,?,?,?,?,?,?)");
			 ps.setString(1, s.getSupplier_name());
			 ps.setString(2, s.getCity());
			 ps.setString(3, s.getAddress());
			 ps.setString(4, s.getE_mail_id());
			 ps.setString(5, s.getFax());
			 ps.setString(6, s.getPhone_no());
			 ps.setString(7, s.getContact_person());
			 r=ps.executeUpdate();
			 if(r>0)
				 msg=msg+"Successfully Inserted";
			 con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
			
		return msg;
	}
	@Override
	public String editSupplier(Supplier s) {
		int r=0;
		String msg="";
		PreparedStatement p=null;
		try{
		con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME,DBConstants.PWD);
		//PreparedStatement ps=con.prepareStatement("Select * from supplier where id=?");
		//ps.setInt(1, s.getId());
		//ResultSet rs=ps.executeQuery();
		/*if(!(s.getSupplier_name().equalsIgnoreCase((rs.getString(2)))))
				{
					 p=con.prepareStatement("update supplier set supplier_name=? where supplier_name=?");
					p.setString(1,s.getSupplier_name());
					p.setString(2,rs.getString(2));
				}
		if(!(s.getCity().equalsIgnoreCase((rs.getString(3)))))
		{
			 p=con.prepareStatement("update supplier set city=? where city=?");
			p.setString(1,s.getCity());
			p.setString(2,rs.getString(3));
		}
		if(!(s.getAddress().equalsIgnoreCase((rs.getString(4)))))
		{
			 p=con.prepareStatement("update supplier set address=? where address=?");
			p.setString(1,s.getAddress());
			p.setString(2,rs.getString(4));
		}
		if(!(s.getE_mail_id().equalsIgnoreCase((rs.getString(5)))))
		{
			 p=con.prepareStatement("update supplier set e_mail_id=? where e_mail_id=?");
			p.setString(1,s.getE_mail_id());
			p.setString(2,rs.getString(5));
		}
		if(!(s.getFax().equalsIgnoreCase((rs.getString(6)))))
		{
			 p=con.prepareStatement("update supplier set fax=? where fax=?");
			p.setString(1,s.getFax());
			p.setString(2,rs.getString(6));
		}
		if(!(s.getPhone_no().equalsIgnoreCase((rs.getString(7)))))
		{
			 p=con.prepareStatement("update supplier set phone_no=? where phone_no=?");
			p.setString(1,s.getPhone_no());
			p.setString(2,rs.getString(7));
		}
		if(!(s.getContact_person().equalsIgnoreCase((rs.getString(8)))))
		{
			 p=con.prepareStatement("update supplier set contact_person=? where contact_person=?");
			p.setString(1,s.getContact_person());
			p.setString(2,rs.getString(8));
		}
	*/
		p=con.prepareStatement("update supplier set supplier_name=?,city=?,address=?,e_mail_id=?,fax=?,phone_no=?,contact_person=? where id=?");
		p.setString(1,s.getSupplier_name());
		p.setString(2,s.getCity());
		p.setString(3,s.getAddress());
		p.setString(4,s.getE_mail_id());
		p.setString(5,s.getFax());
		p.setString(6,s.getPhone_no());
		p.setString(7,s.getContact_person());
		p.setInt(8, s.getId());
		 r=p.executeUpdate();
		 if(r>0)
			 msg=msg+"Successfully Inserted";
		 else
			 msg+="Insertion failed";
		 con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return msg;
	}
	@Override
	public String deleteSupplier(Supplier s) {
		// TODO Auto-generated method stub
		
		PreparedStatement ps=null;
		int r=0;
		String msg="";
		try{
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME,DBConstants.PWD);
			 ps=con.prepareStatement("delete from supplier where id=?");
			 ps.setInt(1, s.getId());
			 r=ps.executeUpdate();
			 if(r>0)
				 msg=msg+"Successfully Deleted";
			 con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
			
		return msg;
	}
	public List<Supplier> getSuppliers()
	{
		List<Supplier> suppliers=new ArrayList<>();
		Connection con=null;
		Statement st=null;
		try {
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME,DBConstants.PWD);
			st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from supplier");
			while(rs.next())
			{
				suppliers.add(new Supplier(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return suppliers;
		
	}
	@Override
	public int getId(String name) {
		int id=0;
		Supplier s=null;
		try{
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME,DBConstants.PWD);
			PreparedStatement ps=con.prepareStatement("Select id from supplier where supplier_name=?");
			ps.setString(1,name);
			ResultSet rs=ps.executeQuery();
			rs.next();
			id=rs.getInt(1);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return id;
	}
   
}
