package org.cts.dao;

import java.util.ArrayList;
import java.util.List;

import org.cts.model.Supplier;

public interface SupplierDao {
             public Supplier getSupplier(int id); 
             public String editSupplier(Supplier s);
             public String deleteSupplier(Supplier s);
            public String addSupplier(Supplier s);
            public List<Supplier> getSuppliers();
            public int getId(String name);
             
}
