package org.cts.dao;

import java.util.List;

import org.cts.model.Cart;
import org.cts.model.Item;

public interface CartDao {
	String addItem(Item item);
	String deleteItem(int id);
	List<Cart> getCartList(int supplierId); 

}
