package org.cts.dao;

import java.util.List;

import org.cts.model.Item;

public interface ItemDao {
	String addItem(Item t);
	String delete(Item t);
	Item getItem1(int itemId);
	List<Item> getItem(int supplierId);
    
}
