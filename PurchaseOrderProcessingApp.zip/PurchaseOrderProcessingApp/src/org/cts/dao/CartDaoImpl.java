package org.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import org.cts.model.Cart;
import org.cts.model.Item;
import org.cts.util.DBConstants;
import org.cts.util.DBUtil;

public class CartDaoImpl implements CartDao{

	@Override
	public String addItem(Item item) {
		Connection con=null;
		PreparedStatement ps=null;
		try{
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME,DBConstants.PWD);
			 ps=con.prepareStatement("insert into cart(description,available_quantity,reorder_level,status,puchase_cost,purchase_quantity,supplier_id) value(?,?,?,?,?,?,?)");
			
			 con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String deleteItem(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cart> getCartList(int supplierId) {
		// TODO Auto-generated method stub
		return null;
	}

}
