package org.cts.model;

public class Cart {
	private int id;
	private int item_id;
	private double totalCost;
	private int quantity;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getItem_id() {
		return item_id;
	}
	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Cart(int item_id, int quantity) {
		super();
		this.item_id = item_id;
		this.quantity = quantity;
	}
	public double getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}
	public Cart(int item_id, double totalCost, int quantity) {
		super();
		this.item_id = item_id;
		this.totalCost = totalCost;
		this.quantity = quantity;
	}
	public Cart(int id, int item_id, double totalCost, int quantity) {
		super();
		this.id = id;
		this.item_id = item_id;
		this.totalCost = totalCost;
		this.quantity = quantity;
	}
	
}