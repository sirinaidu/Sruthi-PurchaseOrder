package org.cts.model;
import java.util.List;


public class Supplier {
	 private int id;
	 private String supplier_name;
	 private String city;
	 private String address;
	 private String e_mail_id;
	 private String fax;
	 private String phone_no;
	 private String contact_person;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSupplier_name() {
		return supplier_name;
	}
	public void setSupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getE_mail_id() {
		return e_mail_id;
	}
	public void setE_mail_id(String e_mail_id) {
		this.e_mail_id = e_mail_id;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	public String getContact_person() {
		return contact_person;
	}
	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}
	public Supplier(String supplier_name, String city, String address,
			String e_mail_id, String fax, String phone_no, String contact_person) {
		super();
		this.supplier_name = supplier_name;
		this.city = city;
		this.address = address;
		this.e_mail_id = e_mail_id;
		this.fax = fax;
		this.phone_no = phone_no;
		this.contact_person = contact_person;
	}
	public Supplier(int id, String supplier_name, String city, String address,
			String e_mail_id, String fax, String phone_no, String contact_person) {
		super();
		this.id = id;
		this.supplier_name = supplier_name;
		this.city = city;
		this.address = address;
		this.e_mail_id = e_mail_id;
		this.fax = fax;
		this.phone_no = phone_no;
		this.contact_person = contact_person;
	}

	/* public static List<Supplier> prefill(List<Supplier> details)
	 {
		 details.add(new Supplier(1,"Sunitha","Chennai","JJ Ladies Hostel,Mettukuppam,pin code:54999","sunitha.obbalareddy@gmail.com","91-40-123456","7981524645","Sunitha"));
		 details.add(new Supplier(2,"Tuhin","Jamshedpur","Agrico, jsr, pin code: 831009","tuhinsinha673@gmail.com","91-657-333333","9471575333","Sweta"));
		 details.add(new Supplier(3,"Sasmita","Bhubaneswar","Jayadurga Nagar,pin code: 751006","sasmitas.12345@gmail.com","91-674-232323","8763578485","Ankita"));
		 details.add(new Supplier(4,"Sruthi","Kurnool","Kamalapuri,sanjamala,pin code:518196","sruthi.gourigari@gmail.com","91-40-456789","8465851741","Sruthi"));
		 details.add(new Supplier(5,"Sounak","Kolkata","Ultadanga,pin code: 700067","sounakpaul.sp@gmail.com","91-33-123456789","9836115359","Arijit"));
		 //details.add(new Supplier(6,"sai","Rajhamundry","Hyderabad,pin code:531033));
		 return details;
	 }*/
}