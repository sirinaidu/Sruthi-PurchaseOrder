package org.cts.model;

public class Item {
	
		private int id;
		private String description;
		private int availableQuantity;
		private int reorderLevel;
		private int purchaseCost;
		private int supplierId;
		private String imageURL;
		
		public String getImageURL() {
			return imageURL;
		}

		public void setImageURL(String imageURL) {
			this.imageURL = imageURL;
		}

		public Item() {
			// TODO Auto-generated constructor stub
		}

		public Item(int id, String description, int availableQuantity,
				int reorderLevel, int purchaseCost, int supplierId,
				String imageURL) {
			super();
			this.id = id;
			this.description = description;
			this.availableQuantity = availableQuantity;
			this.reorderLevel = reorderLevel;
			this.purchaseCost = purchaseCost;
			this.supplierId = supplierId;
			this.imageURL = imageURL;
		}

		public Item(String description, int availableQuantity,
				int reorderLevel, int purchaseCost, int supplierId,
				String imageURL) {
			super();
			this.description = description;
			this.availableQuantity = availableQuantity;
			this.reorderLevel = reorderLevel;
			this.purchaseCost = purchaseCost;
			this.supplierId = supplierId;
			this.imageURL = imageURL;
		}

		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public int getAvailableQuantity() {
			return availableQuantity;
		}
		public void setAvailableQuantity(int availableQuantity) {
			this.availableQuantity = availableQuantity;
		}
		public int getReorderLevel() {
			return reorderLevel;
		}
		public void setReorderLevel(int reorderLevel) {
			this.reorderLevel = reorderLevel;
		}
		
		public int getPurchaseCost() {
			return purchaseCost;
		}
		public void setPurchaseCost(int purchaseCost) {
			this.purchaseCost = purchaseCost;
		}
		
		public int getSupplierId() {
			return supplierId;
		}
		public void setSupplierId(int supplierId) {
			this.supplierId = supplierId;
		}
		
}

