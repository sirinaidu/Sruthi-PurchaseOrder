package org.cts;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.dao.SupplierBO;
import org.cts.model.Supplier;

/**
 * Servlet implementation class EditSupplier
 */
@WebServlet("/edit")
public class EditSupplier extends HttpServlet {
	private static final long serialVersionUID = 1L;
	SupplierBO supplierBo=new SupplierBO();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int id=Integer.parseInt(request.getParameter("id"));
		Supplier supplier=supplierBo.getSupplier(id);
		request.setAttribute("supplier", supplier);
		request.setAttribute("edit", true);
		pw.println("<script type=\"text/javascript\">");
		pw.println("alert('Successfully updated);");
		pw.println("</script>");
		RequestDispatcher rd=request.getRequestDispatcher("addSupplier.jsp");
		rd.include(request, response);
	}

}
