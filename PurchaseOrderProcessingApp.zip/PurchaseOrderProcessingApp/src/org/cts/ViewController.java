package org.cts;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.dao.ItemDaoImpl;
import org.cts.model.Item;

/**
 * Servlet implementation class ViewController
 */
@WebServlet("/view")
public class ViewController extends HttpServlet {
	private static final long serialVersionUID = 1L;
     ItemDaoImpl item=new ItemDaoImpl();
 	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		/*String description=request.getParameter("desc");
		String available_quantity=request.getParameter("city");
		String reorder_level=request.getParameter("address");
		//String status=request.getParameter("email");
		String puchase_cost=request.getParameter("fax");
		//String puchase_quantity=request.getParameter("phone");
	    int supplier_id=Integer.parseInt(request.getParameter("contactPerson"));
		String msg=item.addItem(new Item(description,available_quantity,reorder_level,puchase_cost,supplier_id));*/
		List<Item> it=new ArrayList<Item>();
		ItemDaoImpl di=new ItemDaoImpl();
		//it=di.getItem(supplierId);
		for(Item i:it)
		{
			if(i.getId()==1)
			{
				request.setAttribute("n1", i.getDescription());
				request.setAttribute("n2", i.getPurchaseCost());
				request.setAttribute("n3", i.getId());
				
			}
			if(i.getId()==2)
			{
				request.setAttribute("n4", i.getDescription());
				request.setAttribute("n5", i.getPurchaseCost());
				request.setAttribute("n6", i.getId());
				
			}
			if(i.getId()==3)
			{
				request.setAttribute("n7", i.getDescription());
				request.setAttribute("n8", i.getPurchaseCost());
				request.setAttribute("n9", i.getId());
				
			}
			if(i.getId()==4)
			{
				request.setAttribute("n10", i.getDescription());
				request.setAttribute("n11", i.getPurchaseCost());
				request.setAttribute("n12", i.getId());
				
			}
			if(i.getId()==5)
			{
				request.setAttribute("n13", i.getDescription());
				request.setAttribute("n14", i.getPurchaseCost());
				request.setAttribute("n15", i.getId());
				
			}
			if(i.getId()==6)
			{
				request.setAttribute("n16", i.getDescription());
				request.setAttribute("n17", i.getPurchaseCost());
				request.setAttribute("n18", i.getId());
				
			}
		}
		RequestDispatcher rd=request.getRequestDispatcher("viewOrder.jsp");
		rd.include(request, response);	

		int s1=(Integer.parseInt(request.getParameter("cost")));
		int s2=(Integer.parseInt(request.getParameter("id")));
		int s11=(Integer.parseInt(request.getParameter("cost1")));
		int s12=(Integer.parseInt(request.getParameter("id1")));
		int s21=(Integer.parseInt(request.getParameter("cost2")));
		int s22=(Integer.parseInt(request.getParameter("id2")));
		int s31=(Integer.parseInt(request.getParameter("cost3")));
		int s32=(Integer.parseInt(request.getParameter("id3")));
		int s41=(Integer.parseInt(request.getParameter("cost4")));
		int s42=(Integer.parseInt(request.getParameter("id4")));
		int s51=(Integer.parseInt(request.getParameter("cost5")));
		int s52=(Integer.parseInt(request.getParameter("id5")));
		
		
		
	}

}
