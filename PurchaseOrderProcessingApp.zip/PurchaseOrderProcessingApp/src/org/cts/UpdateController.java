package org.cts;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.dao.SupplierBO;
import org.cts.model.Supplier;

/**
 * Servlet implementation class UpdateController
 */
@WebServlet("/update")
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	SupplierBO bo=new SupplierBO();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int id=Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		String city=request.getParameter("city");
		String address=request.getParameter("address");
		String email=request.getParameter("email");
		String fax=request.getParameter("fax");
		String phone=request.getParameter("phone");
		String contactPerson=request.getParameter("contactPerson");
		String msg=bo.editSupplier(new Supplier(id,name, city, address, email, fax, phone, contactPerson));
		if(msg.equals("Successfully Inserted"))
		{
		pw.println("<script type=\"text/javascript\">");
		pw.println("alert('Successfully Updated');");
		pw.println("</script>");
		RequestDispatcher rd=request.getRequestDispatcher("supplier.jsp");
		rd.include(request, response);
		}
		else
		{
			pw.println("<script type=\"text/javascript\">");
			pw.println("alert('fails');");
			pw.println("</script>");
			RequestDispatcher rd=request.getRequestDispatcher("supplier.jsp");
			rd.include(request, response);
		}
	}
	
}
